
import controller.Programming;

public class main {
    public static void main(String[] args) {
        // Enter the garbage weights at each station
        
        Programming programming = new Programming();
        
        programming.start();
    }
}