package model;

public interface GINFO {
    int MAXLOAD = 10000;
    int AVG_TIME = 8;
    int AVG_HT = 30;
    int SALARY = 120000;
    int FEE = 57000;
}
